last inthy | grep inthy | wc -l |cat > ./number_connection $Date && tar -czvf $log.tar.gz ./$log 



